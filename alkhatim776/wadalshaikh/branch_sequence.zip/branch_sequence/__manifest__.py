# Copyright 2022 alkhatim tech
{
    "name": "Branch Sequence",
    "summary": "Branch Sequence",
    "version": "15.0.1.0.0",
    "author": "alkhatim tech, ",
    "website": "https://alkhatim.tech",
    "category": "Product",
    "license": "AGPL-3",
    "depends": ['branch'],
    "data": [
        "views/inherit_branch_view.xml",
    ],
    "installable": True,
}
